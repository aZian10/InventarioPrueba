#Funciones del inventario

def agregar_producto(inventario,nombre,precio,cantidad):
    """Agregar un producto al inventario"""
    inventario.append({
        "nombre":nombre,
        "precio":precio,
        "cantidad":cantidad
    })

def mostrar_inventario(inventario):
    """Mostrar todos los productos"""
    if not inventario:
        print("Inventario vacio")
    else:
        for p in inventario:
            print(p)

def buscar_productos(inventario,nombre):
    """Buscar un producto por nombre"""
    for p in inventario:
        if p["nombre"]==nombre:
            return p
    return None

def actualizar_producto(inventario,nombre,nuevo_precio=None,nueva_cantidad=None):
    """Actualizar producto"""
    p=buscar_productos(inventario,nombre)
    if p:
        if nuevo_precio is not None:
            p["precio"]=nuevo_precio
        if nueva_cantidad is not None:
            p["cantidad"]=nueva_cantidad
    else:
        print("Producto no encontrado")

def eliminar_producto(inventario,nombre):
    """Eliminar producto"""
    p=buscar_productos(inventario,nombre)
    if p:
        inventario.remove(p)
    else:
        print("No existe")

def calcular_estadisticas(inventario):
    """Calcula estadisticas"""
    if not inventario:
        return {}
    
    unidades=sum(p["cantidad"] for p in inventario)
    valor=sum(p["precio"]*p["cantidad"] for p in inventario)
    caro=max(inventario, key=lambda x:x["precio"])
    stock=max(inventario, key=lambda x:x["cantidad"])
    #retorna todo en un diccionario
    return{
        "unidades":unidades,
        "valor":valor,
        "caro":caro,
        "stock":stock
    }