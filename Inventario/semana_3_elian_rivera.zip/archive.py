import csv
def guardar_csv(inventario,ruta):
    """Guardar el inventario en CSV"""
    if not inventario:
        print("No hay datos para guardar")
        return
    
    try:
        #abre el archivo en modo escritura
        with open(ruta, "w", newline="") as f:
            writer=csv.writer(f)
            writer.writerow(["nombre","precio","cantidad"])

            for p in inventario:
                writer.writerow([p["nombre"],p["precio"],p["cantidad"]])
        print("Guardado en: ",ruta)

    except Exception as e:
        #si ocurre un error
        print("Error al guardar: ",e)

def cargar_csv(ruta):
    """Cargar inventario desde CSV"""
    inventario=[]
    errores=0
    try:
        #abre el archivo en lectura
        with open(ruta, "r") as f:
            reader=csv.reader(f)
            header=next(reader)

            if header!=["nombre", "precio", "cantidad"]:
                print("Formato incorrecto")
                return []
            for fila in reader:
                try:
                    nombre=fila[0]
                    precio=float(fila[1])
                    cantidad=int(fila[2])
                    if precio<0 or cantidad<0:
                        raise ValueError
                    inventario.append({
                        "nombre":nombre,
                        "precio":precio,
                        "cantidad":cantidad
                    })
                except:
                    #si hay error en fila
                    errores+=1

        print("Cargados:",len(inventario))
        print("Errores:",errores)

        return inventario
    except FileExistsError:
        print("Archivo no encontrado")
        return[]
