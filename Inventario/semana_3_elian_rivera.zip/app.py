from services import *
from archive import *

inventario=[]

#bucle principal
while True:
    print("\n1. Agregar 2. Mostrar 3. Buscar 4. Actualizar 5. Eliminar")
    print("6. Estadisticas 7. Guardar 8. Cargar 9. Salir")

    op=input("Opcion: ")

    try:
        if op=="1":
            #pide datos al usuario
            n=input("Nombre: ")
            p=float(input("Precio: "))
            c=int(input("Cantidad: "))
            agregar_producto(inventario,n,p,c)
        elif op=="2":
            #muestra inventario
            mostrar_inventario(inventario)
        elif op=="3":
            #busca producto
            n=input("Nombre: ")
            print(buscar_productos(inventario,n))
        elif op=="4":
            #actualiza datos
            n=input("Nombre: ")
            p=float(input("Nuevo precio: "))
            c=int(input("Nueva cantidad: "))

            actualizar_producto(
                inventario,
                n,
                float(p) if p else None,
                int(c) if c else None
            )
        elif op=="5":
            #elimina producto
            n=input("Nombre: ")
            eliminar_producto(inventario,n)
        elif op=="6":
            #muestra estadisticas
            est=calcular_estadisticas(inventario)
            print(est)
        elif op=="7":
            #guarda archivo
            ruta=input("Ruta archivo: ")
            guardar_csv(inventario, ruta)
        elif op=="8":
            #carga archivo
            ruta=input("Ruta archivo: ")
            nuevo=cargar_csv(ruta)

            if nuevo:
                r=input("Sobrescribir? S/N: ")
                if r.lower()=="s":
                    inventario=nuevo
                else:
                    inventario.extend(nuevo)
        elif op=="9":
            #Termina el programa
            print("Adios")
            break
        else:
            print("Opcion invalida")

    except:
        #evita que el programa se cierre
        print("Error en datos")